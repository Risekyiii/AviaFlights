<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получение данных из формы
    $username = $_SESSION["username"];
    $gender = $_POST['gender'];
    $last_name = $_POST['last_name'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $birth_date = $_POST['birth_date'];
    $citizenship = $_POST['citizenship'];
    $document_series_number = $_POST['document_series_number'];
    $country_of_issue = $_POST['country_of_issue'];
    $flightId = $_POST['flightId']; // Получение ID рейса

    // Подключение к базе данных
    $host = '127.0.0.1';
    $dbname = 'spacetickets';
    $bdusername = 'postgres';
    $bdpassword = 'postgres';

    try {
        $pdo = new PDO("pgsql:host=$host;port=5432;dbname=$dbname", $bdusername, $bdpassword); 
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Начало транзакции
        $pdo->beginTransaction();

        // Запись данных в таблицу passenger_info
        $query = "INSERT INTO passenger_info (username, gender, last_name, first_name, middle_name, birth_date, citizenship, document_series_number, country_of_issue, flight_id) 
                  VALUES (:username, :gender, :last_name, :first_name, :middle_name, :birth_date, :citizenship, :document_series_number, :country_of_issue, :flightId)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            'username' => $username,
            'gender' => $gender,
            'last_name' => $last_name,
            'first_name' => $first_name,
            'middle_name' => $middle_name,
            'birth_date' => $birth_date,
            'citizenship' => $citizenship,
            'document_series_number' => $document_series_number,
            'country_of_issue' => $country_of_issue,
            'flightId' => $flightId
        ]);

        // Обновление статуса подтверждения билета в таблице places
        $query = "UPDATE places SET is_confirmed = TRUE WHERE flight_id = :flightId AND username = :username";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['flightId' => $flightId, 'username' => $username]);

        // Обновление статуса билета на 'completed' в таблице tickets
        $query = "UPDATE tickets SET status = 'completed' WHERE id = :flightId";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['flightId' => $flightId]);

        // Подтверждение транзакции
        $pdo->commit();

        // Удаление сохраненного значения таймера из localStorage
        echo '<script>window.localStorage.removeItem("timer_' . $flightId . '");</script>';

        // Перенаправление на страницу подтверждения
        header('Location: usertickets.php');
        exit;
    } catch(PDOException $e) {
        // Откат транзакции в случае ошибки
        $pdo->rollBack();
        echo "Ошибка при сохранении данных: " . $e->getMessage();
    }
} else {
    echo "Неверный метод запроса.";
}
?>