<footer>
    <p>©<?php date_default_timezone_set("Europe/Moscow"); echo date("Y"); ?> AviaFlights. Все права защищены.</p>
    <p>Для подробной информацией обращайтесь в офисы предприятия.</p>
</footer>